package miniscala.Week2
import miniscala.Ast.*

sealed abstract class VarEnv {
  def extend(x: Var, v: Int): VarEnv
  def lookup(x: Var): Int
  def makeEmpty(): VarEnv
}

case object NilVarEnv extends VarEnv {
  def makeEmpty(): VarEnv = NilVarEnv
  def extend(x: Var, v: Int): VarEnv = ConsVarEnv(x, v, NilVarEnv)
  def lookup(x: Var): Int = throw new RuntimeException("not found")
}
case class ConsVarEnv(x: Var, v: Int, next: VarEnv) extends VarEnv {
  def makeEmpty(): VarEnv = NilVarEnv
  def extend(x2: Var, v2: Int): VarEnv = ConsVarEnv(x2, v2, ConsVarEnv(x, v, next))
  def lookup(a: Var): Int = {
    if (x == a)
      v
    next.lookup(a)
  }
}